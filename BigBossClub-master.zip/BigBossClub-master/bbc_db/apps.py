from django.apps import AppConfig


class BbcDbConfig(AppConfig):
    name = 'bbc_db'
