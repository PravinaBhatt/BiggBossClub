from django.apps import AppConfig


class BbcDashboardConfig(AppConfig):
    name = 'bbc_dashboard'
